from django.urls import path
from . import views
from django.contrib.auth.views import LoginView

app_name = 'blog'
urlpatterns = [
    path('accounts/login/', LoginView.as_view(template_name='login.html'), name='login'),
    path('register/', views.register, name='register'),
    path('create/', views.create_blog, name='create'),
    path('index/', views.index, name='index'),
    path('home/', views.home, name='home'),
    path('blog/<int:pk>', views.blog_detail, name='blog_detail'),
    path('user/<int:pk>', views.user_detail, name='user_detail'),
    path('review/<int:pk>', views.review, name='review'),
    path('home/delete/<int:pk>', views.delete, name='delete'),
    path('change/<int:pk>', views.change, name='change'),
    path('', views.index, name='default'),
]
