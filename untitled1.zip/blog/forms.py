from django import forms
from ckeditor_uploader.widgets import CKEditorUploadingWidget
from ckeditor_uploader.fields import RichTextUploadingFormField


class BlogForm(forms.Form):
    content = RichTextUploadingFormField(widget=CKEditorUploadingWidget)
