from django.db import models
from ckeditor_uploader.fields import RichTextUploadingField
from django.contrib.auth.models import User
# Create your models here.


class Blog(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    content = RichTextUploadingField()
    date = models.DateTimeField(auto_now_add=True)
    readers = models.IntegerField(default=0)


class Review(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    content = RichTextUploadingField()
    date = models.DateTimeField(auto_now_add=True)
    blog = models.ForeignKey(Blog, on_delete=models.CASCADE)
