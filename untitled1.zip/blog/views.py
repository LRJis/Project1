from django.shortcuts import render, reverse
from django.http import HttpResponseRedirect
from django.contrib.auth.forms import UserCreationForm
from .models import *
from .forms import *
from django.contrib.auth.views import login_required
# Create your views here.


def register(request):
    form = UserCreationForm(request.POST or None)
    error = ''
    if form.is_valid():
        try:
            User.objects.get(username=request.POST['username'])
            error = 'This name is existing...'
        except User.DoesNotExist:
            form.save()
            return HttpResponseRedirect(reverse('blog:index'))
    context = {
        'form': form,
        'error': error,
    }
    return render(request, 'register.html', context)


@login_required
def create_blog(request):
    form = BlogForm(request.POST or None)
    user = User.objects.get(username=request.user.username)
    if form.is_valid():
        user.blog_set.create(content=request.POST['content'])
        return HttpResponseRedirect(reverse('blog:index'))
    context = {
        'form': form,
    }
    return render(request, 'create.html', context)


def index(request):
    all_blog = Blog.objects.order_by('-date')
    context = {
        'all_blog': all_blog,
    }
    return render(request, 'index.html', context)


def get_user(request):
    return User.objects.get(username=request.user.username)


@login_required
def home(request):
    user = get_user(request)
    all_blog = user.blog_set.order_by('-date')
    context = {
        'user': user,
        'all_blog': all_blog,
    }
    return render(request, 'home.html', context)


def blog_detail(request, pk):
    blog = Blog.objects.get(pk=pk)
    form = BlogForm()
    blog.readers = blog.readers + 1
    blog.save()
    context = {
        'blog': blog,
        'form': form,
        'reviews': blog.review_set.order_by('-date'),
    }
    return render(request, 'blog_detail.html', context)


def user_detail(request, pk):
    user = User.objects.get(pk=pk)
    all_blog = user.blog_set.order_by('-date')
    context = {
        'user': user,
        'all_blog': all_blog,
    }
    return render(request, 'user_detail.html', context)


@login_required
def review(request, pk):
    blog = Blog.objects.get(pk=pk)
    form = BlogForm(request.POST or None)
    user = get_user(request)
    if form.is_valid():
        blog.review_set.create(user=user, content=request.POST['content'])
    return HttpResponseRedirect(reverse('blog:blog_detail', args=(blog.pk, )))


@login_required
def delete(request, pk):
    user = get_user(request)
    blog = Blog.objects.get(pk=pk)
    if blog.user == user:
        blog.delete()
        return HttpResponseRedirect(reverse('blog:home'))
    return HttpResponseRedirect(reverse('blog:home'))


@login_required
def change(request, pk):
    form = BlogForm(request.POST or None)
    user = get_user(request)
    blog = Blog.objects.get(pk=pk)
    if blog.user != user:
        return HttpResponseRedirect(reverse('blog:home'))
    if form.is_valid():
        blog.content = request.POST['content']
        blog.save()
        return HttpResponseRedirect(reverse('blog:home'))
    form.content = blog.content
    context = {
        'blog': blog,
        'user': user,
        'form': form,
    }
    return render(request, 'change.html', context)
